// Example: index.js
console.log('Hello, this is the entry point of the extension!');
